# Changes

## Unreleased

## 0.1.4

- Minimum supported Rust version (MSRV) is now 1.65.

## 0.1.3

- Minimum supported Rust version (MSRV) is now 1.49.

## 0.1.2

- Fix crate metadata.

## 0.1.1

- Move `LocalWaker` to it's own crate.
