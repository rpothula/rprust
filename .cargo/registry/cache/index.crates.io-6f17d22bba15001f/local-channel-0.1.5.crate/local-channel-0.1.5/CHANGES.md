# Changes

## Unreleased

## 0.1.5

- No significant changes since `0.1.4`.

## 0.1.4

- Minimum supported Rust version (MSRV) is now 1.65.

## 0.1.3

- Minimum supported Rust version (MSRV) is now 1.49.

## 0.1.2

- No significant changes from `0.1.1`.

## 0.1.1

- Move local MPSC channel to it's own crate.
