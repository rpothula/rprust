use actix_web_codegen::scope;

#[scope]
mod api {}

fn main() {}
