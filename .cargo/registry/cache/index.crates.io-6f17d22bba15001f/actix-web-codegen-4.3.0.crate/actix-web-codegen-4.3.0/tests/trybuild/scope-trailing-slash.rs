use actix_web_codegen::scope;

#[scope("/api/")]
mod api {}

fn main() {}
