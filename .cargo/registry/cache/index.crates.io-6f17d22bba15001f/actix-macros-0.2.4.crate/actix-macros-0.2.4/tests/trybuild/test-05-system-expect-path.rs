#[actix_rt::test(system = "!@#*&")]
async fn my_test() {}

fn main() {}
