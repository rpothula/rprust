#[actix_rt::main(system = "!@#*&")]
async fn main2() {}

fn main() {}
